package com.hfda.playwithwords;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.RelativeLayout;

public class Fragment_Introduction_Mode4 extends Fragment implements View.OnClickListener{
    ImageButton backBtn;
    Button nextBtn;
    Introduction _container;
    public Fragment_Introduction_Mode4() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState)
    {

        super.onCreate(savedInstanceState);
        _container=(Introduction)getActivity();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState)
    {
        // Inflate the layout for this fragment
        RelativeLayout layout = (RelativeLayout)inflater.inflate(R.layout.fragment_introduction_mode4, container, false);

        nextBtn=layout.findViewById(R.id.btn_next);
        backBtn=layout.findViewById(R.id.btn_back);

        nextBtn.setOnClickListener(this);
        backBtn.setOnClickListener(this);

        return layout;
    }
    /*Send infor to Introduction*/
    @Override
    public void onClick(View v)
    {
        String action=null;

        if(v.getId() == nextBtn.getId())
        {

            action="NEXT";

        }
        if(v.getId() == backBtn.getId())
        {

            action="BACK";
        }
        _container.itemClicked(action,"");
    }
}
