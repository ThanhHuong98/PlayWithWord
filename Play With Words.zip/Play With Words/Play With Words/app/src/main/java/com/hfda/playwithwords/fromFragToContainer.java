package com.hfda.playwithwords;

import android.view.View;

public interface fromFragToContainer
{
    void itemClicked(String action, String question); //tham so dau de cho item trong giao dien bi click
                                            //tham so thu hai la de xac dinh la vao mode nao tu lua chon o menu
}
