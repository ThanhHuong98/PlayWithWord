package com.hfda.playwithwords;

import android.content.Intent;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import static android.widget.Toast.LENGTH_SHORT;
/*Activity chứa Fragmen_Introduction_modex*/

public class Introduction extends AppCompatActivity implements fromFragToContainer {
    Fragment fragment;
    int currentMode = 4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_introduction);

        //Intent intent = getIntent();
        switch (currentMode) {
            case 1:
                /*fragment = new Fragment_Introduction_Mode1();
                break;*/
            case 2:
                //fragment = new Fragment_Introduction_Mode2();
                break;
            case 3:
                //fragment = new Fragment_Introduction_Mode3();
                break;
            case 4:
                fragment = new Fragment_Introduction_Mode4();
                break;
        }
        //Create a new Frgment_Round_Modex and Show it
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.add(R.id.fragment_intro, fragment);
        //ft.remove(fragment);
        // ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
        ft.commit();

    }

    //de luc nao bam back no cung quay ve man hinh menu.
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(this, Menu.class));
    }

    //cai interface de nhan thong tin cua btn duoc click và mode hien hanh o fragment_introduc_modex gui len
    @Override
    public void itemClicked(String action, String question) {
        Intent intent = null;
        /*switch(mode)
        {
            case 1:
                fragment = new Fragment_Introduction_Mode1();
                break;
            case 2:
                break;
            case 3:
                break;
            case 4:
                fragment = new Fragment_Introduction_Mode4();
                break;
        }*/

        if (action.equals("NEXT")) {
            intent = new Intent(Introduction.this, Round.class); //neu nhan nut Next thi chuyen intent qua Round
            intent.putExtra(Round.MODE, currentMode + ""); //de xac dinh duoc mode nao dang hien hanh
            Toast.makeText(this, action, LENGTH_SHORT).show();
        }
        if (action.equals("BACK")) {

            intent = new Intent(this, Menu.class); //neu nhan nut Back thi chuyen intent ve Menu
            Toast.makeText(this, action, LENGTH_SHORT).show();
        }
        startActivity(intent);

    }

}
