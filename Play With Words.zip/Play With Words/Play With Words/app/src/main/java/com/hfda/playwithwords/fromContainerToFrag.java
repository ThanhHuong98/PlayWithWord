package com.hfda.playwithwords;

public interface fromContainerToFrag {
    public void message(String mess, String round,Object question, String transcription, String[] answerInBtn);
    //volume from database
}
