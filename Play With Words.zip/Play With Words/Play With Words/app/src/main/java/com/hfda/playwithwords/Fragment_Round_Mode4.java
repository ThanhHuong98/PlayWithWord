package com.hfda.playwithwords;


import android.media.MediaPlayer;
import android.media.SoundPool;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import static android.content.Context.AUDIO_SERVICE;
import static android.widget.Toast.LENGTH_LONG;


/**
 * A simple {@link Fragment} subclass.
 */
public class Fragment_Round_Mode4 extends Fragment {//implements fromContainerToFrag {
    ImageButton btnVolume;
    EditText editTextAnswer;
    Button btnDone;
    ImageButton btnHint;
    TextView textViewNumberHint;
    TextView textViewPoint;
    //public int resID;




    int hint = 5;
    Round mainRoundMode4;


    public Fragment_Round_Mode4() {
        // Required empty public constructor
    }
    @Override
    public void onCreate(Bundle savedInstanceState)
    {

        super.onCreate(savedInstanceState);
       mainRoundMode4=(Round) getActivity();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_round_mode4, container, false);
        btnVolume=(ImageButton) view.findViewById(R.id.btn_volume);
        editTextAnswer=(EditText)view.findViewById(R.id.editText_Answer);
        btnDone=(Button)view.findViewById(R.id.btn_done);
        btnHint=(ImageButton)view.findViewById(R.id.btnHint);
        textViewNumberHint=(TextView)view.findViewById(R.id.textViewNumberHint);
        textViewPoint=(TextView)view.findViewById(R.id.textViewPoint);


        btnVolume.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String action="handlerSoundVolume";
                mainRoundMode4.itemClicked(action,"");
            }
        });

       btnDone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String action="handlerDone";
                String result = editTextAnswer.getText().toString();
                mainRoundMode4.itemClicked(action,result);
            }
        });
        btnHint.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String action="handlerHint";
                String notification="";
                hint--;
                String strHint=hint+"";
                //Handler Split String: Hint: 3/5;
                if(hint>=0){
                    textViewNumberHint.setText("Hint: "+strHint+""+"/5");
                    mainRoundMode4.itemClicked(action,"");
                    notification="Decrease the number of Hint...";
                    //Then, make sure update point by setText() on textViewPoint...
                }
                else{
                  notification="You must use Pont to buy Hint..... ";
                }
                mainRoundMode4.itemClicked(action,notification);
            }
        });


        return view;
    }

    //@Override
    /*public void message(String mess, String round, Object question, String transcription, String[] answerInBtn) {
        //transcription =""; answerInBtn[]=""
        resID=R.raw.milk;

    }*/

}
