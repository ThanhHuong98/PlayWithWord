package com.hfda.playwithwords;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;

public class Round extends AppCompatActivity implements fromFragToContainer{
    static final String MODE = "mode";
    Context context;
    //Đừng để ý đến mode 4, đang bug chỗ Database Sound

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_round);

        int round = 1;
        Intent intent = getIntent();
        String m = intent.getStringExtra(MODE);
        int mode = Integer.parseInt(m);

        Fragment fragmentRound = null;//= new Fragment();
        switch (mode) {
            case 1:
               /* fragmentRound = new Fragment_Round_Mode1();
                break;*/
            case 2:
                break;
            case 3:
                break;
            case 4:
                fragmentRound = new Fragment_Round_Mode4();
                break;
        }

        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.fragment_round, fragmentRound);
        //  ft.addToBackStack("round " + round);
        //  ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
        ft.commit();
        context=getApplicationContext();
        //SoundManager.initialize(getApplicationContext());
        /*public static void initialize(Context context){
            SoundManager soundManager = getInstance();
            soundManager.loadSound(context);
        }*/


    }

    @Override
    public void itemClicked(String action, String question) {
        //Handler btnVolume: phát ra âm thanh của wordx.mp3
        if (action.equals("handlerSoundVolume")) {

            //SoundManager.getInstance().playClickSound();
            SoundManager soundManager=new SoundManager();
            soundManager.loadSound(context,R.raw.milk);


            Toast.makeText(this, "Click btnVolume", Toast.LENGTH_LONG).show();
        }

        else if (action.equals("handlerDone")) {
            if (question.equals("vegetable")) {
                //Right - Then, load newFragmentRound on the Activity
                Toast.makeText(this, "Right", Toast.LENGTH_SHORT).show();
            } else if(question.equals("")){
               //EditText_Answer = """
                Toast.makeText(this, "you must write down \n" +
                        "at least one character ", Toast.LENGTH_SHORT).show();
            }
            else{
                //Wrong - Then, load newFragmentRound on the Activity
                Toast.makeText(this, "Wrong", Toast.LENGTH_SHORT).show();
            }
        }
        //Another action.......
        else if(action.equals("handlerHint")){
            //Toast.makeText(this, "Click Hint", Toast.LENGTH_SHORT).show();
            Toast.makeText(this,question,Toast.LENGTH_LONG).show();

        }
        else{
            Toast.makeText(this, "Another Fragment...", Toast.LENGTH_SHORT).show();
        }

    }



}
